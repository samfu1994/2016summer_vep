cri = []
data = []     

var app = angular.module('demo',[]);

function getCri(){
    app.controller('midCtrl', function($q){
      authorized = false;
      this.authorized = false;
      d3.csv("data/criterion.csv", function(error, csv){
            cri = csv;
            this.cri = cri;
            d3.csv("data/output.csv", function(error, csv){
                data = csv;
                this.data = data;
                console.log(data);
                return $q(function(resolve, reject) {
                        resolve('Hello');
                  });
            });
          }
      )
     });
}

getCri();
console.log(Date());
sum = 0;
for(i = 0; i < 2000000000; i++)
    sum += 1;
console.log(Date());

var promise = getCri();
//promise.then(function() {
//  alert('Success: ');
//    console.log(data);
//}, function() {
//  alert('fail: ');
//    console.log(data);
//});
//getData();
//showPage();
           